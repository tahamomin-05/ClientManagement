import { Component } from '@angular/core';
import { FormControl, FormGroup, FormControlName } from '@angular/forms';
@Component({
  selector: 'app-create-meeting',
  templateUrl: './create-meeting.component.html',
  styleUrl: './create-meeting.component.css'
})
export class CreateMeetingComponent {

  createMeeting = new FormGroup({
    mtopic:new FormControl(""),
    nPeople:new FormControl(""),
    startTime:new FormControl("")
  });

  meetingCreated() {
    console.log(this.createMeeting.value);
    alert("Meeting Created with Title :"+this.createMeeting.value.mtopic +" Successfully.");
  }
}
