import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterClientComponent } from './register-client/register-client.component';
import { CreateMeetingComponent } from './create-meeting/create-meeting.component';
const routes: Routes = [
  {
    path:'registerClient',
    component:RegisterClientComponent
  },
  {
    path:'createMeeting',
    component:CreateMeetingComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
