import { Component } from '@angular/core';
import { RegisterClientComponent } from './register-client/register-client.component';
import { CreateMeetingComponent } from './create-meeting/create-meeting.component';
import { FormControl, FormGroup, FormControlName } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'clientManagement';

}
