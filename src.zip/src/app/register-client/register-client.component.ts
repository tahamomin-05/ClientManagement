import { Component } from '@angular/core';
import { FormControl, FormGroup, FormControlName } from '@angular/forms';

@Component({
  selector: 'app-register-client',
  templateUrl: './register-client.component.html',
  styleUrl: './register-client.component.css'
})
export class RegisterClientComponent {

  registerClient = new FormGroup({
    cname:new FormControl(""),
    cemail:new FormControl(""),
    address:new FormControl(""),
    cpassword:new FormControl(""),
    rpassword:new FormControl("")
  });

  clientRegistered() {
    console.log(this.registerClient.value);
    alert("Client "+ this.registerClient.value.cname + " is registed Successfully.")
  }
}
